<template>
  <div class="404">
      <h2>404</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
h2{
    color: red;
    background: url() cover no-repeat;
}
</style>