<template>
  <div>
      你当前没有权限访问这个页面，请联系管理员
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>