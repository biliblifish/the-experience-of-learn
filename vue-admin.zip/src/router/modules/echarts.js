import home from '@/view/Index/home'

export default {
    path: '/echarts',
    name: '统计数据',
    // component: home,
    component: () => import('@/view/Echarts/echarts.vue')
    // children: [
    //     {
    //         path: '/echarts',
    //         name: '各种图表',
    //         component: () => import('@/view/Echarts/echarts.vue')
    //     }
    // ]
}